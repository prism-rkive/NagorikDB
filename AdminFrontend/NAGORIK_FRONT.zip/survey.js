document.addEventListener("DOMContentLoaded", async () => {
    const surveyContainer = document.getElementById("survey-container");

    try {
        // Fetch surveys from the backend
        const response = await fetch("http://localhost:8080/api/surveys");

        if (!response.ok) {
            throw new Error(`Error fetching surveys: ${response.statusText}`);
        }

        const surveys = await response.json();

        // If no surveys are available
        if (surveys.length === 0) {
            surveyContainer.innerHTML = `
                <div class="col-12">
                    <p class="text-center text-muted">No surveys are available at the moment.</p>
                </div>`;
            return;
        }

        // Generate survey cards
        surveys.forEach(async (survey, index) => {
            const surveyCard = document.createElement("div");
            surveyCard.className = "col-md-6 mb-4";

            const bgColor = index % 2 === 0 ? "#f8f9fa" : "#e9ecef";

            surveyCard.innerHTML = `
                <div class="card h-100" style="background-color: ${bgColor}" data-survey-id="${survey.surveyId}">
                    <div class="card-body">
                        <h5 class="card-title">${survey.question}</h5>
                        <p class="card-text text-muted">
                            <strong>Starts:</strong> ${formatDate(survey.startTime)}<br>
                            <strong>Ends:</strong> ${formatDate(survey.endTime)}
                        </p>
                        <div class="d-flex justify-content-between mt-3">
                            <button class="btn btn-success" onclick="vote(${survey.surveyId}, 'yes')">
                                Yes
                            </button>
                            <button class="btn btn-danger" onclick="vote(${survey.surveyId}, 'no')">
                                No
                            </button>
                        </div>
                        <div class="mt-3">
                            <p class="statistics text-primary">Loading stats...</p>
                        </div>
                    </div>
                </div>`;

            surveyContainer.appendChild(surveyCard);

            // Fetch initial statistics
            const statsResponse = await fetch(`http://localhost:8080/api/participations/survey/${survey.surveyId}/statistics`);
            const stats = statsResponse.ok ? await statsResponse.text() : "No data available";

            const statsElement = surveyCard.querySelector(".statistics");
            statsElement.textContent = stats;
        });
    } catch (error) {
        console.error("Error loading surveys:", error);
        surveyContainer.innerHTML = `
            <div class="col-12">
                <p class="text-center text-danger">Failed to load surveys. Please try again later.</p>
            </div>`;
    }
});

// Function to format date for better readability
function formatDate(dateTime) {
    if (!dateTime) return "N/A";
    const date = new Date(dateTime);
    return date.toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" });
}

// Function to handle voting and update stats
async function vote(surveyId, choice) {
    try {
        const userId = localStorage.getItem("userId"); // Ensure this is the actual user ID

        // Prepare the vote payload
        const votePayload = {
            survey: { id: surveyId }, 
            user: { id: userId },    // Adjusted to match User entity
            response: choice,        // "Yes" or "No"
            submissionTime: new Date().toISOString(),
        };

        console.log("Submitting vote payload:", votePayload); // Debug log

        // Send vote to the backend
        const response = await fetch("http://localhost:8080/api/participations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(votePayload), // Properly serialized JSON
        });

        if (!response.ok) {
            throw new Error(`Error submitting vote: ${response.statusText}`);
        }

        // Fetch updated statistics
        const statsResponse = await fetch(`http://localhost:8080/api/participations/survey/${surveyId}/statistics`);
        if (!statsResponse.ok) {
            throw new Error(`Error fetching statistics: ${statsResponse.statusText}`);
        }

        const stats = await statsResponse.text();
        const surveyCard = document.querySelector(`[data-survey-id="${surveyId}"]`);
        const statsElement = surveyCard.querySelector(".statistics");
        statsElement.textContent = stats;

        alert(`Vote recorded successfully! Updated stats: ${stats}`);
    } catch (error) {
        console.error("Error during voting:", error);
        alert("Failed to submit your vote. Please try again later.");
    }
}
