document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault(); // Prevent form submission reload

        const nid = document.getElementById("nid").value;
        const password = document.getElementById("password").value;

        try {
            const response = await fetch("http://localhost:8080/api/users/authenticate", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: new URLSearchParams({ nid, password }),
            });

            if (response.ok) {
                // Show success message on the same page
                const successMessage = document.createElement("p");
                successMessage.textContent = "Login successful! Redirecting...";
                successMessage.style.color = "white";
                successMessage.style.fontWeight = "bold";
                successMessage.style.textAlign = "center";
                document.body.appendChild(successMessage);  // Add the success message to the page

                // Redirect to homepage after a delay of 2 seconds
                setTimeout(() => {
                    window.location.href = "homepg.html"; // Change this to your homepage route
                }, 2000); // Delay of 2 seconds (2000ms)
            } else {
                const errorMessage = await response.text();
                alert(`Login failed: ${errorMessage}`);
            }
        } catch (error) {
            console.error("Error during login:", error);
            alert("An error occurred while trying to log in.");
        }
    });
});
